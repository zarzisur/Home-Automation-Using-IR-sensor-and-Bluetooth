/*
 * Home_Automation.c
 *
 * Created: 10/12/2019 6:21:41 PM
 * Author : Rony
 */ 

/*
 * 9600.c
 *
 * Created: 4/27/2019 10:23:50 PM
 * Author : Rony
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#define F_CPU 1000000UL;
void initalizeUART(void);
volatile unsigned char flag=0;

int main(void)
{
    /* Replace with your application code */
	initalizeUART();//9600,1 stop bit, no parity, 8 data bit
	DDRB |=(1<<PINB0)|(1<<PINB1);
	DDRB &=~(1<<PINB2);//PINB2 as INPUT
	PORTB |=(1<<PINB0)|(1<<PINB1);// High value will make relay off
	
    while (1) 
    {
		
		if( (PINB & (1<<PINB2))>0 )// input is high
		{	
			PORTB &=~(1<<PINB0);//  output is low so light is on.
				
		}//end if
		
    
	}//end while
}// end main

void initalizeUART()
{
	// double speed operation ,U2X=1
	//BAUD RATE=9600
	uint16_t UBBRValue =12;
	//put the upper part of the baud number here( bits 8 to 11)
	UBRR0H =(unsigned char ) (UBBRValue>>8);
	// Put the remaining part of the baud number here
	UBRR0L =(unsigned char ) UBBRValue;
	UCSR0A |=(1<<U2X0)	;// double speed operation
	
	// Enable the receiver and Transmitter and receive interrupt
	UCSR0B |=(1<<RXEN0) | (1<<TXEN0) |(1<<RXCIE0);
	sei();//enable global interrupt
	// by default 1 stop bit
	//by default no parity
	UCSR0C |=(1<<UCSZ00)|(1<<UCSZ01);//8 bit
}



ISR(USART_RX_vect)
 {
	while(!(UCSR0A & (1<<RXC0)));
	unsigned char received = UDR0;
	flag=1;
	
	switch( received )
	{
		case 'a':// Appliance 1 is on
		PORTB &=~(1<<PINB0);
		break;
		case 'b':// Appliance 1 is off
		PORTB |=(1<<PINB0);
		break;
		case 1:// Appliance 2 is On
		PORTB &=~(1<<PINB1);
		break;
		case 2:// Appliance 2 is off
		PORTB |=(1<<PINB1);
		break;
		default:
		break;
	}
}

